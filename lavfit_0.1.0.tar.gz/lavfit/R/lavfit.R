
lavfit<-function(X){
  nb.var = length(X@pta$vnames$ov.model[[1]])-length(X@pta$vnames$ov.y[[1]])
  nb.fac = unlist(X@pta$nfac)[1]

  p = parameterEstimates(X, standardized = T)
  p = p[1:nb.var,'std.all']
  p = abs(p)

  struc = X@Model@GLIST$lambda
  struc[struc!=0] = 1
  struc = struc[,colSums(struc)>1]
  struc = struc[rowSums(struc)>0,]
  r = struc*p

  coefs = matrix(0,nrow=nb.fac,ncol=2)
  colnames(coefs) = c("CR","AVE")
  rownames(coefs) = unlist(X@pta$vnames$lv)

  for (i in 1:nb.fac){
    dim = r[,i]
    dim = dim[dim!=0]

    a = dim^2
    sum.a = sum(a)
    b = 1-a
    sum.b = sum(b)
    sum2 = (sum(dim))^2

    coefs[i,1] = sum2/(sum2+sum.b)
    coefs[i,2] = sum.a/(sum.a+sum.b)
  }
  coefs<-round(coefs,digits=3)
  print(coefs)
}
